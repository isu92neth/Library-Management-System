export const CATALOG = "/catalog";
export const DASHBOARD = "/dashboard";
